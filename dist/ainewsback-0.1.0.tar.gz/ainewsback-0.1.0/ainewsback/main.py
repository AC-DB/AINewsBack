import uvicorn
from fastapi import FastAPI

from ainewsback.config import settings

app = FastAPI(
    title=settings.APP_NAME,
    description=settings.APP_DESCRIPTION,
    version=settings.APP_VERSION,
    contact=settings.ADMIN_CONTACT,
    license_info=settings.APP_LICENSE,
    debug=settings.DEBUG
)


@app.get("/")
async def root():
    return {"message": "Hello World"}


@app.get("/info")
async def info():
    return {
        "app_name": settings.APP_NAME,
        "app_version": settings.APP_VERSION,
        "app_description": settings.APP_DESCRIPTION,
        "app_license": settings.APP_LICENSE,
        "admin_name": settings.ADMIN_CONTACT.get("name"),
        "admin_email": settings.ADMIN_CONTACT.get("email"),
        "app_env": settings.APP_ENV,
        "debug": settings.DEBUG,
        "log_level": settings.LOG_LEVEL,
        "host": settings.HOST,
        "port": settings.PORT,
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host=settings.HOST, port=settings.PORT,
                reload=settings.DEBUG)
